'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const P = require('../labs/spectrometer/physics.js');
const R = require('../labs/spectrometer/realism-optics.js');

// Run the actual application's functions and event handlers, replacing only
// its final render so these tests do not claim to verify browser layout.
const appPath = path.join(__dirname, '../labs/spectrometer/app.js');
const source = fs.readFileSync(appPath, 'utf8');
const boot = '  showStorage();render();\n})();';
assert.ok(source.endsWith(boot + '\n') || source.endsWith(boot), 'Update the app test seam after bootstrap changes.');
const testSource = source.replace(boot, `
  globalThis.appTest={getState:()=>state,checks,ready,prismReady,measurementReady,checkAction,changedSetup,
    measurementGate,capture,savePair,pendingPair,targetAngle,simulatedReadings,
    renderAdjustment,renderSimulation,setIdeal};
})();`);

function harness(saved) {
  const elements = new Map(), listeners = new Map();
  function element(selector) {
    if (!elements.has(selector)) elements.set(selector, {
      value:'',textContent:'',innerHTML:'',checked:false,disabled:false,dataset:{},
      classList:{add(){},remove(){}},setAttribute(){},
      addEventListener(name, handler){this['on'+name]=handler;}
    });
    return elements.get(selector);
  }
  let id=0, persisted;
  const window = {SpectrometerPhysics:P,SpectrometerRealism:R,addEventListener(){},scrollTo(){}};
  const context = {
    window,parent:window,
    document:{querySelector:element,querySelectorAll(selector){
      if(selector==='[data-prism-axis]'&&element('#app').innerHTML.includes('data-prism-axis'))return ['x','y'].map(axis=>{
        const input=element('#prism-tilt-'+axis);input.dataset.prismAxis=axis;return input;
      });
      return [];
    },
      addEventListener(name,handler){listeners.set(name,handler);}},
    localStorage:{getItem(){return JSON.stringify(saved??null);},setItem(key,value){persisted=value;}},
    crypto:{randomUUID(){return 'workflow-'+(++id);}},
    setTimeout(){return 1;},clearTimeout(){},confirm(){return true;},
    location:{origin:'https://example.test',hash:'#adjustment'}
  };
  vm.runInNewContext(testSource,context,{filename:appPath});
  const click = (buttonId,dataset={}) => {
    const button={id:buttonId,dataset,hasAttribute(){return false;},closest(){return this;}};
    listeners.get('click')({target:button});
  };
  return {app:context.appTest,element,click,getPersisted:()=>JSON.parse(persisted)};
}

function zeroAdjustments(h) {
  for (const key of Object.keys(h.app.getState().adjust)) h.app.getState().adjust[key]=0;
  h.app.renderAdjustment();
}
function moveEyes(h) {
  for (const value of [-1,1,0]) h.element('#eye-position').oninput({target:{value:String(value)}});
}
function checkTelescope(h) {
  zeroAdjustments(h);moveEyes(h);h.app.checkAction('parallax-check');
  h.app.checkAction('face-check');
  h.click('',{face:'AC'});h.app.checkAction('face-check');
}
function realReady() {
  const h=harness();checkTelescope(h);
  h.element('#slit-orientation').onchange({target:{value:'horizontal'}});
  h.app.checkAction('collimator-check');
  h.element('#slit-orientation').onchange({target:{value:'vertical'}});
  h.app.checkAction('grating-check');
  assert.equal(h.app.ready(),true);
  return h;
}
function position(h,side='left',offsetMinutes=0) {
  const s=h.app.getState();s.sim.side=side;
  s.sim.angleMinutes=Math.round(h.app.targetAngle()*60)+offsetMinutes;
  s.lab.telescopeLocked=true;s.lab.lockAnchor=s.sim.angleMinutes;
}
function fillDial(h) {
  const actual=h.app.simulatedReadings();
  // Different accepted notation and surrounding spaces must survive capture.
  const v1=' '+actual.v1.replace('°',' ').replace('′','')+' ';
  const v2=actual.v2;
  h.element('#reading-one').value=v1;h.element('#reading-two').value=v2;
  return {v1,v2};
}
function prismSetup() {
  const h=realReady();h.app.getState().sim.mode='prism';h.app.renderSimulation();return h;
}
function changePrismTilt(h,axis,value) {
  const input=h.element('#prism-tilt-'+axis);input.value=String(value);input.oninput();
}
function alignedPrism() {
  const h=prismSetup();changePrismTilt(h,'x',0);changePrismTilt(h,'y',0);
  for(const side of ['left','right']){position(h,side);h.click('prism-face-check');}
  assert.equal(h.app.prismReady(),true);return h;
}

test('zeroing focus alone or moving eyes without checking cannot pass parallax',()=>{
  const h=harness();zeroAdjustments(h);
  h.app.checkAction('parallax-check');
  assert.equal(h.app.getState().lab.parallaxChecked,false);
  h.element('#eye-position').oninput({target:{value:'-1'}});
  h.app.checkAction('parallax-check');
  assert.equal(h.app.getState().lab.parallaxChecked,false);
  h.element('#eye-position').oninput({target:{value:'1'}});
  assert.equal(h.app.checks()[1].ok,false);
  h.app.checkAction('parallax-check');
  assert.equal(h.app.checks()[1].ok,true);
  h.app.changedSetup('focus');
  assert.equal(h.app.getState().lab.parallaxChecked,false);
  assert.equal(h.app.getState().lab.eyeSeen.left,false);
  assert.equal(h.app.getState().lab.eyeSeen.right,false);
});

test('single mirror face cannot pass two-face check, and misaligned back face is rejected',()=>{
  const h=harness();zeroAdjustments(h);moveEyes(h);h.app.checkAction('parallax-check');
  h.app.checkAction('face-check');
  assert.equal(h.app.getState().lab.faces.AB,true);
  assert.equal(h.app.checks()[2].ok,false);
  h.click('',{face:'AC'});
  h.app.getState().adjust.stageTilt=.5;
  h.app.checkAction('face-check');
  assert.equal(h.app.getState().lab.faces.AC,false);
  h.app.getState().adjust.stageTilt=0;
  h.app.checkAction('face-check');
  assert.equal(h.app.checks()[2].ok,true);
  h.app.changedSetup('stageTilt');
  assert.equal(h.app.getState().lab.faces.AB,false);
  assert.equal(h.app.getState().lab.faces.AC,false);
});

test('horizontal slit inspection must precede vertical measurement and grating inspection',()=>{
  const h=harness();checkTelescope(h);
  h.app.checkAction('collimator-check');
  assert.equal(h.app.getState().lab.collChecked,false);
  h.element('#slit-orientation').onchange({target:{value:'horizontal'}});
  h.app.checkAction('collimator-check');
  assert.equal(h.app.getState().lab.collChecked,true);
  assert.equal(h.app.checks()[3].ok,false);
  h.app.checkAction('grating-check');
  assert.equal(h.app.getState().lab.gratingChecked,false);
  h.element('#slit-orientation').onchange({target:{value:'vertical'}});
  assert.equal(h.app.checks()[3].ok,true);
  h.app.checkAction('grating-check');
  assert.equal(h.app.ready(),true);
  assert.equal(h.app.getState().lab.demo,false);
});

test('all setup knobs invalidate unfinished pairs without deleting saved records',()=>{
  for (const key of ['eye','focus','stageTilt','telescopeTilt','collFocus','collTilt','normal','grooves']) {
    const h=realReady(),s=h.app.getState();
    position(h);fillDial(h);h.app.capture();
    assert.ok(h.app.pendingPair().left,key);
    s.rows.push({id:'keep-saved-row'});
    h.app.changedSetup(key);
    assert.equal(Object.keys(s.pending).length,0,key);
    assert.equal(s.rows[0].id,'keep-saved-row',key);
  }
});

test('dark illumination prevents inspection and capture even in free mode',()=>{
  const h=realReady(),s=h.app.getState();position(h);
  s.lab.lampOn=false;s.lab.free=true;
  assert.match(h.app.measurementGate(),/照明/);
  fillDial(h);h.app.capture();assert.equal(Object.keys(s.pending).length,0);
  h.app.changedSetup('focus');moveEyes(h);h.app.checkAction('parallax-check');
  assert.equal(s.lab.parallaxChecked,false);
});

test('telescope locking gates capture, disables coarse rotation and bounds fine adjustment',()=>{
  const h=realReady(),s=h.app.getState();position(h);s.lab.telescopeLocked=false;
  assert.match(h.app.measurementGate(),/锁紧/);
  fillDial(h);h.app.capture();assert.equal(Object.keys(s.pending).length,0);
  h.app.renderSimulation();h.click('telescope-lock');
  assert.equal(h.app.measurementGate(),'');
  assert.equal(h.element('#telescope-angle').disabled,true);
  const initial=s.sim.angleMinutes;
  h.element('#telescope-angle').oninput({target:{value:String(initial+100)}});
  assert.equal(s.sim.angleMinutes,initial);
  for (let i=0;i<31;i++)h.click('',{nudge:'1'});
  assert.equal(s.sim.angleMinutes,initial+30);
  h.click('telescope-lock');h.click('',{nudge:'-1'});
  assert.equal(s.sim.angleMinutes,initial+30);
});

test('manual capture and saved pair retain the exact entered strings',()=>{
  const h=realReady(),s=h.app.getState();
  position(h,'left');const left=fillDial(h);h.app.capture();
  assert.equal(h.app.pendingPair().left.v1,left.v1);
  position(h,'right');const right=fillDial(h);h.app.capture();h.app.savePair();
  assert.equal(s.rows.length,1);
  assert.equal(s.rows[0].left1,left.v1);assert.equal(s.rows[0].left2,left.v2);
  assert.equal(s.rows[0].right1,right.v1);assert.equal(s.rows[0].right2,right.v2);
  assert.equal(s.rows[0].practice,true);assert.equal(s.rows[0].demoInstrument,false);
  assert.equal(h.getPersisted().rows[0].left1,left.v1);
});

test('guided capture rejects syntactically valid dial misreading and malformed minutes',()=>{
  const h=realReady();position(h);
  h.element('#reading-one').value='200 00';h.element('#reading-two').value='20 00';
  h.app.capture();assert.equal(h.app.pendingPair().left,undefined);
  assert.match(h.element('#reading-error').textContent,/刻度窗/);
  fillDial(h);h.element('#reading-one').value='12 60';h.app.capture();
  assert.equal(h.app.pendingPair().left,undefined);
  assert.match(h.element('#reading-error').textContent,/小于 60/);
});

test('free measurement accepts real off-center dial readings and records angular offset',()=>{
  const h=realReady(),s=h.app.getState();position(h,'left',12);
  assert.match(h.app.measurementGate(),/准线/);
  fillDial(h);h.app.capture();assert.equal(h.app.pendingPair().left,undefined);
  s.lab.free=true;assert.equal(h.app.measurementGate(),'');
  const raw=fillDial(h);h.app.capture();
  assert.equal(h.app.pendingPair().left.v1,raw.v1);
  assert.ok(Math.abs(h.app.pendingPair().left.offsetArcmin)>10);
});

test('free measurement still rejects a different dial reading and malformed input',()=>{
  const h=realReady(),s=h.app.getState();position(h,'left',12);s.lab.free=true;
  h.element('#reading-one').value='200 00';h.element('#reading-two').value='20 00';
  h.app.capture();assert.equal(h.app.pendingPair().left,undefined,'Free mode allows optical misalignment, not inventing a reading different from the visible dial.');
  fillDial(h);h.element('#reading-one').value='12 60';h.app.capture();
  assert.equal(h.app.pendingPair().left,undefined);
  assert.match(h.element('#reading-error').textContent,/小于 60/);
});

test('wide slit restricts guided yellow-doublet readings but not the isolated green line',()=>{
  const h=realReady(),s=h.app.getState();s.lab.slitWidth=.6;
  position(h);assert.equal(h.app.measurementGate(),'');
  s.sim.line='yellow1';position(h);assert.match(h.app.measurementGate(),/狭缝/);
  s.sim.line='yellow2';position(h);assert.match(h.app.measurementGate(),/狭缝/);
  s.lab.free=true;assert.equal(h.app.measurementGate(),'');
  s.lab.telescopeLocked=false;assert.match(h.app.measurementGate(),/锁紧/);
});

test('half-adjustment controls halve the current mirror gap then remove the remainder',()=>{
  const h=harness();zeroAdjustments(h);moveEyes(h);h.app.checkAction('parallax-check');
  const s=h.app.getState();s.adjust.stageTilt=1.2;s.adjust.telescopeTilt=.4;
  const first=s.adjust.stageTilt-s.adjust.telescopeTilt;
  h.click('half-stage');
  assert.ok(Math.abs((s.adjust.stageTilt-s.adjust.telescopeTilt)-first/2)<1e-9);
  h.click('half-telescope');
  assert.ok(Math.abs(s.adjust.stageTilt-s.adjust.telescopeTilt)<1e-9);
  h.click('',{face:'AC'});
  assert.ok(Math.abs(-s.adjust.stageTilt-s.adjust.telescopeTilt)>.15,'Aligning one face must not imply the other is aligned.');
});

test('changing slit width or grating discards unfinished capture without deleting saved rows',()=>{
  for(const control of ['width','grating']) {
    const h=realReady(),s=h.app.getState();h.app.renderSimulation();position(h);fillDial(h);h.app.capture();
    assert.ok(h.app.pendingPair().left);
    s.rows.push({id:'saved'});
    if(control==='width')h.element('#sim-slit-width').oninput({target:{value:'.2'}});
    else h.element('#sim-density').onchange({target:{value:'350'}});
    assert.equal(Object.keys(s.pending).length,0);
    assert.equal(s.rows[0].id,'saved');
    assert.equal(h.element('#reading-one').value,'');
  }
});

test('demonstration cannot be marked as personally completed and a knob exits demo',()=>{
  const h=harness();h.app.setIdeal();h.click('',{complete:'adjustment'});
  assert.equal(h.app.getState().completed.includes('adjustment'),false);
  h.app.changedSetup('normal');
  const l=h.app.getState().lab;
  assert.equal(l.demo,false);assert.equal(l.parallaxChecked,false);
  assert.equal(l.faces.AB,false);assert.equal(l.faces.AC,false);
  assert.equal(l.prismFaces.AB,false);assert.equal(l.prismFaces.AC,false);
  assert.equal(l.collChecked,false);assert.equal(l.gratingChecked,false);
});

test('reload preserves completed observations and raw rows but unlocks and discards half-pairs',()=>{
  const h=realReady(),s=h.app.getState();position(h);fillDial(h);h.app.capture();
  const restored=harness(s),rs=restored.app.getState();
  assert.equal(restored.app.ready(),true);
  assert.equal(rs.lab.telescopeLocked,false);
  assert.equal(Object.keys(rs.pending).length,0);
});

test('new prism placement requires its own two-face checks and cannot borrow the plane-mirror checks',()=>{
  const h=prismSetup(),s=h.app.getState();
  assert.equal(s.lab.faces.AB,true);assert.equal(s.lab.faces.AC,true);
  position(h,'left');assert.equal(h.app.measurementReady(),false);
  assert.match(h.app.measurementGate(),/三棱镜/);
  changePrismTilt(h,'x',0);changePrismTilt(h,'y',0);
  assert.equal(h.app.prismReady(),false,'Zeroing the platform does not record the observations.');
  h.click('prism-face-check');assert.equal(s.lab.prismFaces.AB,true);
  assert.equal(s.lab.prismFaces.AC,false);assert.equal(h.app.prismReady(),false);
  position(h,'right');h.click('prism-face-check');
  assert.equal(s.lab.prismFaces.AC,true);assert.equal(h.app.prismReady(),true);
  assert.equal(h.app.measurementGate(),'');
});

test('prism check requires the selected face direction and that face normal to be vertically aligned',()=>{
  const h=prismSetup(),s=h.app.getState();
  // Make only the left face's projected platform inclination zero.
  changePrismTilt(h,'x',Math.sqrt(3)*.4);changePrismTilt(h,'y',.4);
  position(h,'left',4);h.click('prism-face-check');
  assert.equal(s.lab.prismFaces.AB,false,'Right height at wrong bearing is insufficient.');
  position(h,'left');h.click('prism-face-check');
  assert.equal(s.lab.prismFaces.AB,true);
  s.sim.side='right';h.click('prism-face-check');
  assert.equal(s.lab.prismFaces.AC,false,'Changing the face label does not move the telescope.');
  position(h,'right');h.click('prism-face-check');
  assert.equal(s.lab.prismFaces.AC,false,'Correct bearing cannot hide the second face height error.');
  assert.equal(h.app.prismReady(),false);
});

test('prism platform input invalidates both face checks and half-pair but keeps telescope pitch and saved data',()=>{
  for(const axis of ['x','y']) {
    const h=alignedPrism(),s=h.app.getState();position(h,'left');fillDial(h);h.app.capture();
    assert.ok(h.app.pendingPair().left);s.rows.push({id:'saved-prism'});
    const pitch=s.adjust.telescopeTilt;changePrismTilt(h,axis,.1);
    assert.equal(s.lab.prismFaces.AB,false);assert.equal(s.lab.prismFaces.AC,false);
    assert.equal(Object.keys(s.pending).length,0);assert.equal(s.rows[0].id,'saved-prism');
    assert.equal(s.adjust.telescopeTilt,pitch);assert.equal(h.app.measurementReady(),false);
  }
});

test('changing common stage or telescope pitch invalidates prism verification',()=>{
  for(const key of ['stageTilt','telescopeTilt']) {
    const h=alignedPrism(),s=h.app.getState();h.app.changedSetup(key);
    assert.equal(s.lab.prismFaces.AB,false,key);assert.equal(s.lab.prismFaces.AC,false,key);
    assert.equal(h.app.prismReady(),false,key);
  }
});

test('prism checking cannot bypass illumination, focus or the original two-face alignment',()=>{
  for(const missing of ['light','focus','mirror']) {
    const h=prismSetup(),s=h.app.getState();changePrismTilt(h,'x',0);changePrismTilt(h,'y',0);position(h);
    if(missing==='light')s.lab.lampOn=false;
    else if(missing==='focus')s.lab.parallaxChecked=false;
    else s.lab.faces.AC=false;
    h.click('prism-face-check');assert.equal(s.lab.prismFaces.AB,false,missing);
  }
});

test('prism measurements preserve handwritten readings and recover the supplementary apex angle',()=>{
  const h=alignedPrism(),s=h.app.getState();
  position(h,'left');const left=fillDial(h);h.app.capture();
  position(h,'right');const right=fillDial(h);h.app.capture();h.app.savePair();
  assert.equal(s.rows.length,1);assert.equal(s.rows[0].kind,'prism');
  assert.equal(s.rows[0].left1,left.v1);assert.equal(s.rows[0].right1,right.v1);
  assert.ok(Math.abs(P.analyzePrismPair(s.rows[0]).apexAngleDeg-60)<1/60);
});

test('ideal prism inspection is explicitly marked as demonstration',()=>{
  const h=prismSetup();h.app.setIdeal();
  assert.equal(h.app.prismReady(),true);assert.equal(h.app.getState().lab.demo,true);
  assert.equal(h.app.getState().lab.prismTilt.x,0);assert.equal(h.app.getState().lab.prismTilt.y,0);
});
