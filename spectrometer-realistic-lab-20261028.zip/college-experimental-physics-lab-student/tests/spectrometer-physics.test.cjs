'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const P = require('../labs/spectrometer/physics.js');
const close = (actual, expected, tolerance = 1e-9) => assert.ok(Math.abs(actual - expected) <= tolerance, `${actual} != ${expected}`);
const pair = (left, right, extra = {}) => ({
  left1:P.normalizeAngle(left), left2:P.normalizeAngle(left + 180),
  right1:P.normalizeAngle(right), right2:P.normalizeAngle(right + 180), ...extra
});
const spectralRow = (line, phiDeg, center = 5, extra = {}) => pair(center - phiDeg, center + phiDeg, {line, order:2, ...extra});

test('reads decimal and sexagesimal angles without treating 1 minute as 0.01 degree', () => {
  close(P.parseAngle('123.5'), 123.5);
  close(P.parseAngle('123 45'), 123.75);
  close(P.parseAngle('123°45′'), 123.75);
  close(P.parseAngle('123:45:30'), 123 + 45/60 + 30/3600);
  close(P.parseAngle('123度45分30秒'), 123 + 45/60 + 30/3600);
  close(P.parseAngle('0°00′'), 0);
  close(P.parseAngle(359.999), 359.999);
});

test('rejects absent, malformed, out-of-range and non-finite readings', () => {
  for (const input of ['', ' ', null, undefined, NaN, Infinity, -1, 360, '360°00′', '-1', '12°60′', '12:59:60', '12 30 junk', '12.5 30']) {
    assert.throws(() => P.parseAngle(input), Error, String(input));
  }
});

test('formatting handles minute carrying and the 360-degree boundary', () => {
  assert.equal(P.formatAngle(123.75), '123°45′');
  assert.equal(P.formatAngle(12 + 59.6 / 60), '013°00′');
  assert.equal(P.formatAngle(359 + 59.6 / 60), '000°00′');
  assert.equal(P.formatAngle(-1), '359°00′');
  assert.equal(P.formatAngle(12 + 30.5 / 60, 1), '012°30.5′');
  assert.throws(() => P.formatAngle(NaN));
});

test('guidebook circle-crossing examples and directed differences', () => {
  close(P.angleSeparation(P.parseAngle('355°45′'), P.parseAngle('115°43′')), 119 + 58/60);
  close(P.angleSeparation(P.parseAngle('340°20′'), P.parseAngle('16°01′')), 35 + 41/60);
  close(P.angularDifference(350, 10), 20);
  close(P.angularDifference(10, 350), -20);
});

test('dual verniers yield the 60-degree prism apex across zero', () => {
  const result = P.analyzePrismPair(pair(355, 115));
  close(result.thetaDeg, 120);
  close(result.apexAngleDeg, 60);
  const reversed = P.analyzePrismPair(pair(115, 355));
  close(reversed.apexAngleDeg, 60);
});

test('correct half-angle and order recover the green wavelength with ±2 readings', () => {
  const phi = P.diffractionAngle(546.07, 300, 2);
  const result = P.analyzeGratingPair(spectralRow('green', phi), {linesPerMm:300});
  close(result.phiDeg, phi);
  close(result.wavelengthNm, 546.07);
  close(result.relativeErrorPercent, 0);
  assert.equal(result.order, 2);
  assert.equal(result.warnings.length, 0);
});

test('invalid opposing verniers and duplicated measurement positions cannot silently produce a result', () => {
  assert.throws(() => P.analyzeGratingPair({...pair(340, 20), left2:100}), /180/);
  assert.throws(() => P.analyzePrismPair(pair(10, 10)), /相同/);
  assert.throws(() => P.analyzeGratingPair({...pair(340,20), right1:''}), /第二位置/);
  assert.throws(() => P.analyzeGratingPair({...pair(340,20), line:'red'}), /绿线/);
  assert.throws(() => P.analyzeGratingPair({...pair(340,20), line:'toString'}), /绿线/);
  assert.throws(() => P.analyzeGratingPair({...pair(340,20), line:'__proto__'}), /绿线/);
  assert.throws(() => P.analyzeGratingPair({...pair(340,20), order:0}), /正整数/);
  assert.throws(() => P.analyzeGratingPair(pair(340,20), {linesPerMm:0}), /大于/);
});

test('inaccessible diffraction orders reject their physical domain', () => {
  assert.throws(() => P.diffractionAngle(600, 1000, 2), /kλ/);
  assert.throws(() => P.diffractionAngle(500, 1000, 2), /kλ/);
  assert.throws(() => P.diffractionAngle(-1, 300, 2), /大于/);
});

test('sample dispersion and standard error require repeat measurements', () => {
  const stats = P.summarize([1,2,3]);
  assert.equal(stats.count, 3); close(stats.mean, 2); close(stats.sampleStdDev, 1);
  close(stats.standardError, 1/Math.sqrt(3));
  assert.equal(P.summarize([5]).standardError, null);
  assert.equal(P.summarize([]).mean, null);
  assert.throws(() => P.summarize([1, NaN]));
});

test('dataset calibrates from mean green angle then evaluates mean yellow angle, preserving error sign', () => {
  const phiG = P.diffractionAngle(546.07, 300, 2);
  const phiY = P.diffractionAngle(576.96, 300, 2);
  const rows = [spectralRow('green', phiG - 0.05), spectralRow('green', phiG + 0.05),
    spectralRow('yellow1', phiY - 0.03), spectralRow('yellow1', phiY + 0.01)];
  const result = P.analyzeDataset(rows, {linesPerMm:280});
  assert.equal(result.calibrationSource, 'green');
  close(result.calibratedSpacingNm, 1e6/300);
  close(result.calibratedLinesPerMm, 300);
  assert.equal(result.calibrationCount, 2);
  const green = result.groups.find(g => g.line === 'green');
  close(green.meanWavelengthNm, 546.07);
  const yellow = result.groups.find(g => g.line === 'yellow1');
  close(yellow.meanPhiDeg, phiY - 0.01);
  close(yellow.meanWavelengthNm, (1e6/300) * Math.sin((phiY - 0.01) * Math.PI/180)/2);
  assert.ok(yellow.relativeErrorPercent < 0);
  assert.ok(yellow.standardErrorNm > 0);
  assert.ok(Math.abs(yellow.meanWavelengthNm - yellow.rowMeanWavelengthNm) > 1e-8);
});

test('dataset reports invalid rows and nominal fallback instead of corrupting averages', () => {
  const phi = P.diffractionAngle(579.07, 300, 2);
  const result = P.analyzeDataset([spectralRow('yellow2', phi), {...spectralRow('green', 19), left1:''}], {linesPerMm:300});
  assert.equal(result.errors.length, 1);
  assert.equal(result.errors[0].index, 1);
  assert.equal(result.rows.length, 1);
  assert.equal(result.calibrationSource, 'nominal');
  assert.equal(result.calibratedSpacingNm, null);
  close(result.groups[0].meanWavelengthNm, 579.07);
  assert.equal(result.groups[0].standardErrorNm, null);
});

test('different orders stay in separate groups and second-order green has calibration priority', () => {
  const rows = [spectralRow('green', P.diffractionAngle(546.07, 300, 1), 0, {order:1}),
    spectralRow('green', P.diffractionAngle(546.07, 300, 2))];
  const result = P.analyzeDataset(rows);
  assert.equal(result.groups.length, 2);
  assert.equal(result.calibrationOrder, 2);
  close(result.calibratedLinesPerMm, 300);
});
