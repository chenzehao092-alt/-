'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const P = require('../labs/spectrometer/physics.js');

// Exercise the real app's persistence and data-selection functions. A small DOM
// stub keeps this a data regression test; browser layout is checked separately.
const appPath = path.join(__dirname, '../labs/spectrometer/app.js');
const source = fs.readFileSync(appPath, 'utf8');
const boot = '  showStorage();render();\n})();';
assert.ok(source.endsWith(boot + '\n') || source.endsWith(boot), 'App bootstrap changed; update the test seam.');
const testSource = source.replace(boot, `  renderData=function(){};
  globalThis.appTest={getState:()=>state,setState:s=>{state=s;},activeRows,dataset,prismDataset,addManual};
})();`);

function harness(saved) {
  const elements = new Map();
  const element = selector => {
    if (!elements.has(selector)) elements.set(selector, {value:'',textContent:'',classList:{add(){},remove(){}}});
    return elements.get(selector);
  };
  let id=0, persisted=null;
  const context = {
    window:{SpectrometerPhysics:P,addEventListener(){}},
    document:{querySelector:element,querySelectorAll(){return [];},addEventListener(){}},
    localStorage:{getItem(){return typeof saved==='string'?saved:JSON.stringify(saved??null);},setItem(key,value){persisted=value;}},
    crypto:{randomUUID(){return 'generated-' + (++id);}},
    setTimeout(){return 1;},clearTimeout(){},
    location:{origin:'https://example.test',hash:'#data'}
  };
  vm.runInNewContext(testSource, context, {filename:appPath});
  return {app:context.appTest,element,getPersisted:()=>JSON.parse(persisted)};
}

function row(id,source,density,line='green',round=1) {
  return {id,source,nominalDensity:density,line,round,kind:'grating',order:2,
    left1:'340°00′',left2:'160°00′',right1:'020°00′',right2:'200°00′'};
}

test('manual measurements from different nominal gratings cannot share a calibration', () => {
  const {app}=harness({version:1,dataSource:'measurement',nominalDensity:350,rows:[
    row('green-real-300','measurement',300),
    row('yellow-real-350','measurement',350,'yellow1'),
    row('green-sim-350','simulation',350)
  ]});
  assert.deepEqual(Array.from(app.activeRows(),r=>r.id),['yellow-real-350']);
  const result=app.dataset();
  assert.equal(result.calibrationSource,'nominal');
  assert.equal(result.calibratedSpacingNm,null);
  assert.equal(result.rows.length,1);
  assert.ok(Math.abs(result.effectiveSpacingNm-1e6/350)<1e-9);
});

test('simulation selection keeps source and grating groups separate, while prism records stay with their source', () => {
  const {app}=harness({version:1,dataSource:'simulation',sim:{linesPerMm:300},rows:[
    row('sim-300','simulation',300),row('sim-350','simulation',350),row('real-300','measurement',300),
    {...row('prism-sim','simulation',350),kind:'prism',line:'prism'},
    {...row('prism-real','measurement',300),kind:'prism',line:'prism'}
  ]});
  assert.deepEqual(Array.from(app.activeRows(),r=>r.id),['sim-300','prism-sim']);
  assert.equal(app.dataset().rows.length,1);
});

test('restoration deduplicates completion and record identities without changing raw angle strings', () => {
  const {app,getPersisted}=harness({version:1,completed:['data','data','principle','unknown'],
    sim:{line:'toString',mode:'grating',round:3},rows:[row('same','measurement',300),row('same','measurement',300),row(undefined,'measurement',300)]});
  const state=app.getState();
  assert.equal(state.completed.length,2);
  assert.equal(state.sim.line,'green');
  assert.equal(state.sim.round,2);
  assert.equal(new Set(state.rows.map(r=>r.id)).size,3);
  for(const restored of state.rows)assert.equal(restored.left1,'340°00′');
  assert.equal(new Set(getPersisted().rows.map(r=>r.id)).size,3);
});

test('malformed storage cannot prevent default initialization, while invalid raw readings remain visible as errors', () => {
  const broken=harness('{invalid json');
  assert.equal(broken.app.getState().rows.length,0);
  assert.equal(broken.app.getState().sim.line,'green');
  const {app}=harness({version:1,dataSource:'measurement',nominalDensity:300,rows:[{...row('bad','measurement',300),left1:'12°60′'}]});
  assert.equal(app.activeRows().length,1);
  assert.equal(app.dataset().rows.length,0);
  assert.equal(app.dataset().errors.length,1);
  assert.equal(app.getState().rows[0].left1,'12°60′');
});

test('manual round numbering remains unique after deletion and never borrows another density or source', () => {
  const {app,element}=harness({version:1,dataSource:'simulation',nominalDensity:300,rows:[
    row('round1','measurement',300,'green',1),row('round3','measurement',300,'green',3),
    row('other-grating','measurement',350,'green',99),row('simulation','simulation',300,'green',77)
  ]});
  element('#manual-kind').value='grating';element('#manual-line').value='green';
  for(const key of ['left1','left2','right1','right2'])element('#manual-'+key).value=row('new','measurement',300)[key];
  app.addManual();
  const state=app.getState(),added=state.rows[state.rows.length-1];
  assert.equal(added.round,4);
  assert.equal(added.source,'measurement');
  assert.equal(added.nominalDensity,300);
  assert.equal(state.dataSource,'measurement');
  assert.equal(added.left1,'340°00′');
});
