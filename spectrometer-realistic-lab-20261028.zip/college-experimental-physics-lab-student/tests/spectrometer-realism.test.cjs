'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const R = require('../labs/spectrometer/realism-optics.js');

test('30-division vernier reads the half-degree main scale plus the coincident index',()=>{
  const v=R.vernier(123+47/60);
  assert.equal(v.degrees,123);
  assert.equal(v.baseMinutes,30);
  assert.equal(v.minuteIndex,17);
  assert.equal(v.display,'123°47′');
  const matching=v.mainTicks.filter(main=>Math.abs(main.x-v.vernierTicks[17].x)<.0001);
  assert.equal(matching.length,1,'the index used in the reading must physically coincide with a main tick');
  assert.equal(v.mainTicks.some(main=>Math.abs(main.x-v.vernierTicks[16].x)<.0001),false);
  const lowerSpan=v.vernierTicks[30].x-v.vernierTicks[0].x;
  const mainPitch=v.mainTicks[1].x-v.mainTicks[0].x;
  assert.ok(Math.abs(lowerSpan/mainPitch-29)<.0001);
});

test('vernier preserves 359°59′ across wrap, and normalizes minute rounding at zero',()=>{
  const last=R.vernier(359+59/60);
  assert.equal(last.display,'359°59′');
  assert.equal(last.baseMinutes,30);
  assert.equal(last.minuteIndex,29);
  assert.ok(last.mainTicks.some(t=>t.angleDeg===0),'the next degree label wraps to 0 while scale positions remain continuous');
  assert.equal(R.vernier(359+59.8/60).display,'000°00′');
  assert.equal(R.vernier(-1/60).display,'359°59′');
  assert.throws(()=>R.vernier(NaN),/有限/);
});

test('the same field shows both mercury yellow lines at second order, on either side',()=>{
  for(const sign of [-1,1]){
    const first=sign*R.diffractionAngle(576.96,300,2);
    const second=sign*R.diffractionAngle(579.07,300,2);
    assert.ok(Math.abs(second-first)>.07&&Math.abs(second-first)<.09,'the real wavelength separation gives about 4.6 arcminutes at 300 lines/mm');
    const m=R.measurementModel({angleDeg:first,slitWidth:.06});
    const yellows=m.visibleLines.filter(l=>l.id.startsWith('yellow'));
    assert.equal(yellows.length,2);
    assert.ok(Math.abs(yellows[0].x-yellows[1].x)>m.slitWidthPx*2,'narrow slits resolve the close doublet');
    assert.ok(yellows.every(l=>l.order===sign*2));
  }
});

test('widening the slit merges the doublet without inventing a new wavelength or hiding one member',()=>{
  const angleDeg=R.diffractionAngle(576.96,300,2);
  const narrow=R.measurementModel({angleDeg,slitWidth:.03});
  const broad=R.measurementModel({angleDeg,slitWidth:.8});
  const lines=broad.visibleLines.filter(l=>l.id.startsWith('yellow'));
  assert.equal(lines.length,2);
  assert.ok(broad.slitWidthPx>Math.abs(lines[1].x-lines[0].x));
  assert.deepEqual(broad.lines.map(l=>l.angleDeg),narrow.lines.map(l=>l.angleDeg));
});

test('parallax is an image/reticle displacement that disappears after focus, and two focusing controls stay independent',()=>{
  const unfocused=R.adjustmentModel({adjust:{focus:1,eye:0},eyePosition:1});
  const opposite=R.adjustmentModel({adjust:{focus:1,eye:0},eyePosition:-1});
  assert.ok(unfocused.x>120&&opposite.x<120);
  const focused=R.adjustmentModel({adjust:{focus:0,eye:2},eyePosition:1});
  assert.equal(focused.x,120);
  assert.ok(focused.reticleBlur>unfocused.reticleBlur);
  assert.ok(focused.imageBlur<unfocused.imageBlur);
  assert.equal(R.measurementModel({adjust:{focus:0,collFocus:0},eyePosition:1}).parallaxPx,0);
  assert.notEqual(R.measurementModel({adjust:{focus:0,collFocus:1},eyePosition:1}).parallaxPx,0);
});

test('face reversal distinguishes stage tilt from telescope tilt; both faces agree at alignment',()=>{
  const a=R.adjustmentModel({face:'AB',adjust:{stageTilt:1,telescopeTilt:0}});
  const b=R.adjustmentModel({face:'AC',adjust:{stageTilt:1,telescopeTilt:0}});
  assert.ok(a.y>75&&b.y<75);
  const c=R.adjustmentModel({face:'AB',adjust:{stageTilt:0,telescopeTilt:1}});
  const d=R.adjustmentModel({face:'AC',adjust:{stageTilt:0,telescopeTilt:1}});
  assert.equal(c.y,d.y);
  for(const face of ['AB','AC'])assert.equal(R.adjustmentModel({face,adjust:{stageTilt:0,telescopeTilt:0}}).y,75);
});

test('switching off illumination removes light images and a target outside the field cannot remain visible',()=>{
  assert.equal(R.measurementModel({angleDeg:0,lampOn:false}).visibleLines.length,0);
  assert.equal(R.measurementModel({angleDeg:50}).visibleLines.length,0);
  assert.equal(R.measurementModel({mode:'prism',angleDeg:-60}).visibleLines[0].id,'AB');
  assert.equal(R.measurementModel({mode:'prism',angleDeg:60}).visibleLines[0].id,'AC');
  assert.ok(!R.adjustmentScope({lampOn:false}).includes('stroke="#8bffab"'));
  assert.match(R.measurementScope({angleDeg:0}),/圆形仿真目镜视场/);
});

test('triangular-prism platform tilt projects onto two independent face normals',()=>{
  const xFront=R.prismModel({face:'AB',prismTilt:{x:1,y:0}});
  const xBack=R.prismModel({face:'AC',prismTilt:{x:1,y:0}});
  assert.ok(Math.abs(xFront.projectedTilt-.5)<1e-10);
  assert.equal(xFront.y,xBack.y,'x tilt has the same projection on normals at minus/plus 60 degrees');
  const yFront=R.prismModel({face:'AB',prismTilt:{x:0,y:1}});
  const yBack=R.prismModel({face:'AC',prismTilt:{x:0,y:1}});
  assert.ok(yFront.y<95&&yBack.y>95);
  assert.ok(Math.abs((yFront.y+yBack.y)/2-95)<1e-10);
  for(const face of ['AB','AC']){
    const aligned=R.prismModel({face,prismTilt:{x:0,y:0},adjust:{stageTilt:2,telescopeTilt:0}});
    assert.equal(aligned.y,95,'independent prism tilt replaces legacy double-sided-mirror tilt');
    assert.equal(aligned.legacy,false);
  }
  const prism=R.measurementModel({mode:'prism',angleDeg:-60,prismTilt:{x:0,y:1}});
  assert.ok(prism.visibleLines[0].y<95);
  assert.equal(R.prismModel({face:'AB',adjust:{stageTilt:1}}).legacy,true);
});

test('a tilted grating loses left/right symmetry, while its undeflected zero order stays at zero',()=>{
  const aligned=R.measurementModel({adjust:{normal:0}});
  const tilted=R.measurementModel({adjust:{normal:2}});
  assert.equal(tilted.incidenceDeg,1);
  const normalAngles=aligned.lines.filter(l=>l.id==='green').map(l=>l.angleDeg);
  assert.ok(Math.abs(normalAngles[0]+normalAngles[1])<1e-10);
  const pair=tilted.lines.filter(l=>l.id==='green'&&Math.abs(l.order)===2);
  assert.ok(Math.abs(pair[0].angleDeg+pair[1].angleDeg)>.1,'off-normal incidence is visible as an asymmetric spectrum');
  assert.equal(tilted.lines.find(l=>l.order===0).angleDeg,0);
  assert.equal(R.diffractionAngle(546.07,300,0,1),0);
  const reversing=R.measurementModel({adjust:{normal:-2}});
  for(const line of pair){
    const reflected=reversing.lines.find(l=>l.id===line.id&&l.order===-line.order);
    assert.ok(Math.abs(line.angleDeg+reflected.angleDeg)<1e-10);
  }
});

test('nonpropagating grating orders are omitted, never coerced from null into a fake zero-order image',()=>{
  assert.equal(R.diffractionAngle(579.07,900,2),null);
  const model=R.measurementModel({linesPerMm:900,angleDeg:0});
  assert.ok(model.lines.some(l=>l.id==='green'&&l.order===2),'green second order still propagates near grazing');
  assert.ok(!model.lines.some(l=>l.id==='yellow1'&&Math.abs(l.order)===2));
  assert.ok(!model.lines.some(l=>l.id==='yellow2'&&Math.abs(l.order)===2));
  assert.equal(model.lines.filter(l=>l.angleDeg===0).length,1);
  assert.deepEqual(model.visibleLines.map(l=>l.id),['zero']);
});
